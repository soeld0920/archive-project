import type { WrongNote } from "types/note"
import { useContext, useRef, useState } from "react";
import { saveNote } from "lib/storage";
import NoteForm from "./NoteForm";

export default function WrongNoteForm(){
  const LEVELS = [1,2,3,4,5] as const;
  type Difficulty = typeof LEVELS[number];
  const [title, setTitle] = useState("");
  const [problemTitle, setProblemTitle] = useState("");
  const [problemLink, setProblemLink] = useState("");
  const [difficulty, setDifficulty] = useState<Difficulty>(3);
  const [content, setContent] = useState("");
  

  const onSubmit = () => {
    const date = new Date().toISOString();
  
    const note: WrongNote = {
      id : crypto.randomUUID(),
      title : title,
      createdAt : date,
      content : content,
      category : "Wrong",
      problemTitle : problemTitle,
      problemLink : problemLink,
      difficulty : difficulty
    }

    saveNote(note);
  }


  return (
    <>
      <h2>
        새 오답노트 추가
      </h2>
      <input type="text" placeholder="제목 입력" value={title} onChange={(e) => setTitle(e.target.value)}></input><br/>
      <input type="text" placeholder="문제제목 입력" value={problemTitle} onChange={(e) => setProblemTitle(e.target.value)}></input><br/>
      <input type="text" placeholder="문제링크 입력" value={problemLink} onChange={(e) => setProblemLink(e.target.value)}></input><br/>

      <div>
        {
          LEVELS.map(n => {
            const id = n;
            return (
              <label key={id}>
                <input type="radio" name="difficulty" checked={difficulty === id} onChange={() => setDifficulty(id)}/>
                {id}
              </label>
            )
          }
          )
        }
      </div>

      <NoteForm value={content} onChange={setContent}/>

      <button onClick={onSubmit}>제출하기</button>
    </>
  )
}