import Header from "components/layout/Header";
import type { ReactNode } from "react";

type PageFormProps = {
  children : ReactNode,
  title : string;
  subTitle? :string;
  seriesNum? :number
}

export default function PageForm({children, title,subTitle,seriesNum} : PageFormProps){
  return(
    <>
      <Header/>
      <div style={{width:'100%',height : "auto",marginTop : "20px"}}>
        {subTitle && <h4 style={{height: "20px", paddingTop : "5px", paddingLeft : "5px", color : "#aaa"}}>{subTitle}</h4>}
        <h1 style={{height: "50px",borderBottom : "3px solid #666", paddingTop : "10px",paddingLeft : "5px",}}>
          {seriesNum && `#${seriesNum}. `}{title}
        </h1>
        <div style={{display : "flex"}}>
          <div style={{width : "10%", borderRight : "3px solid #666", boxSizing : "border-box", paddingTop : "10px"}}>카테고리분류</div>
          <div style={{width : "70%",height : "auto",marginTop : "10px", marginLeft : "5px"}}>
            {children}
          </div>
        </div>
      </div>
    </>
  )
}