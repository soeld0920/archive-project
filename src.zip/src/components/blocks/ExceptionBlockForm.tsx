import type { ReactNode } from "react";

type ExceptionBlockFormProps = {
  children : ReactNode,
  hasGap? :boolean
}

export default function ExceptionBlockForm({children, hasGap = true} : ExceptionBlockFormProps){
  const gap = hasGap ? "50px" : "20px"
  return(
    <div style={{backgroundColor : "#f9e6ffd8", border : "3px solid #f9e6ff", borderRadius : "20px", padding : "1rem 1.5rem", marginBottom : gap}}>
      <h3>⚠️항상 존재하는 예외</h3>
      <p style={{whiteSpace : "pre-wrap", paddingTop : "5px", fontSize : "13px"}}>
        {children}
      </p>
    </div>
  )
}