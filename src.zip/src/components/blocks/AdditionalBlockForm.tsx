import type { ReactNode } from "react";

type AdditionalBlockFormProps = {
  children : ReactNode,
  hasGap? :boolean,
  title : string
}

export default function AdditionalBlockForm({children, hasGap = true, title} : AdditionalBlockFormProps){
  const gap = hasGap ? "50px" : "20px"
  return(
    <div style={{backgroundColor : "#cbeff2d6", border : "3px solid #9af8ff", borderRadius : "20px", padding : "1rem 1.5rem", marginBottom : gap}}>
      <h3>💡더 알아보기 : {title}</h3>
      <p style={{whiteSpace : "pre-wrap", paddingTop : "5px", fontSize : "13px"}}>
        {children}
      </p>
    </div>
  )
}