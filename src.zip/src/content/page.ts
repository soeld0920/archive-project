export type Page = {
  subCategory? : string;
  id: string;
  title : string;
  seriesNum : number;
  tags : string[];
  date : string;
  summary : string;
  contentPath : string;
}

export const basic : Page[] = [
  {
    id : "programming-basic",
    title : "프로그래밍의 기초",
    seriesNum : 1,
    tags : ["programming","basics"],
    date : "2025-09-04",
    summary : "프로그래밍의 기초 원리",
    contentPath : ""
  },{
    id : "programming-terminology",
    title : "프로그래밍 용어",
    seriesNum : 2,
    tags : ["programming","basics", "terminology"],
    date : "2025-09-04",
    summary : "프로그래밍의 기초 용어",
    contentPath : ""
  },
]